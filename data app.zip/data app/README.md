# ICU Mortality Prediction Using MIMIC-III

This project aims to build a machine learning model to predict ICU mortality using the MIMIC-III dataset.

## 🔍 Objective
Predict patient outcomes using structured ICU data including vitals, lab results, and demographic features.

## ⚙️ Tools and Technologies
- Python, Scikit-learn, XGBoost
- SHAP for model explainability
- Jupyter Notebooks for development
- MIMIC-III clinical dataset

## 📊 Project Structure
- `data/`: notes or synthetic data files (do not upload real MIMIC data)
- `notebooks/`: Jupyter notebooks for EDA, preprocessing, training
- `scripts/`: Python scripts for reusable functions
- `models/`: Trained model files (.pkl)
- `results/`: Visualizations and performance metrics

## 🚀 Getting Started
```bash
pip install -r requirements.txt
jupyter notebook
```

## 📁 LICENSE
This project is licensed under the MIT License.
